package dados;

public class EstatisticaProduto {

}
