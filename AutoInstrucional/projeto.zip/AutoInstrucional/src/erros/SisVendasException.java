package erros;

public class SisVendasException extends Exception {

	public SisVendasException(String mensagem) {
		super(mensagem);
		// TODO Auto-generated constructor stub
	}
	

}
